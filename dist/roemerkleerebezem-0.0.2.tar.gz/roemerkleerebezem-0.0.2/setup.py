import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="roemerkleerebezem",
    version="0.0.2",
    author="Roemer Kleerebezem",
    author_email="roemer.kleerebezem@gmail.com",
    description="Package for personal use",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/roemerkleerebezem/rk-python-package",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)