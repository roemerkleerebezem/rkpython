# roemerkleerebezem python module

## Description
This Python module is created for my own use, but may serve you as well.  
  
## Installation
Use  
```
pip install roemerkleerebezem
```
in your Anaconda Prompt to install the module.  
  
Then import it in Python with 
```python
import roemerkleerebezem as rk
```
## Functions
  
### rk.to_txt(l=None, path='text_file.txt', overwrite=False, verbose = False)
Saves a list to a .txt file.
**l :** Default is None
	List object to be saved.  
**path :** Default is 'text_file.txt'
	File path (with file name) you want to save to.  
**overwrite :** Boolean, default is False  
	Overwrites the file if it exists.
**verbose :** Boolean, default is False
	Prints out a message if the operation was succesful
	
### rk.read_txt(path='text_file.txt', verbose = False)
Reads from a .txt file, saving the result as a list, where each line is one item.
**path :** Default is 'text_file.txt'
	File path (with file name) you want to read from.  
**verbose :** Boolean, default is False
	Prints out a message if the operation was succesful
	