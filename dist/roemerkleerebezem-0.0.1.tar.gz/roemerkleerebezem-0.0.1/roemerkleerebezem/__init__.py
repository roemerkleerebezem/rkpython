# rk.to_txt()

def to_txt(l, path = 'text_file.txt', overwrite = False, verbose = False):

# Check if variables are defined
    if type(l) == list:
        if overwrite == True:
            try: 
                with open(path, 'w') as file:
                    for obj in l:
                        file.write("%s\n" % obj)
                if verbose == True :
                    print(f'File successfully written to {path}')
            except:
                if os.access(path, os.W_OK) == False:
                    raise ValueError(f"No write permissions for the file : {path}. Verify that the file isn't used by another program.")
                else:
                    raise ValueError(f"Could not access the file : {path}.")

        elif os.path.isfile(path):
            raise ValueError(f"File already exists : {path}. Try overwite = True.")
        else :
            try: 
                with open(path, 'w') as file:
                    for obj in l:
                        file.write("%s\n" % obj)
                    if verbose == True :
                        print(f'File successfully written to {path}')
            except:
                raise ValueError(f"Could not write on file : {path}.")
    else :
        raise ValueError(f"Parameter l is not a list.")
		
# rk.read_txt()

def read_txt(path = 'text_file.txt', verbose = False):

	if os.access(path, os.R_OK) == False:
	    raise ValueError(f"No read permissions for the file : {path}. Verify that the file exists.")
	else:
	    with open(path) as file:
	        l = file.read().splitlines()
	        return l
	        if verbose == True :
	            print('Succes de la lecture du fichier .txt')